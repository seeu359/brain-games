print ("hello world") 
 

