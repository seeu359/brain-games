#!/usr/bin/env python
from brain_games.game_logic import *
from brain_games.games.brain_even import *


def main():
    welcome()
    brain_event()


if __name__ == "__main__":
    main()